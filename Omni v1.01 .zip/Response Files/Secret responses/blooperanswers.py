import time

tacos=input("Do you eat tacos?")
if "yes" in tacos:
  print("I just ate a cyber taco")
  time.sleep(3)
  print("I cyber farted")
