greeting1=input("Hello")
print("Which app would you like to open?")
print("1. Clock")
print("2. Youtube (WIP)")
print("3. Twitter (WIP)")
App=input("Which app would u like to use?")
if "2" in App:
  print("Sorry, But Omni has not gained that feature yet.")
if "3" in App:
  print("Sorry, But Omni has not gained that feature yet")
if "1" in App:
  quest2=input("Would you like to open timer?")
  if "yes" in quest2:
    import time

    def countdown(t):
    
      while t:
          mins, secs = divmod(t, 60)
          timer = '{:02d}:{:02d}'.format(mins, secs)
          print(timer, end="\r")
          time.sleep(1)
          t -= 1
      
      print('timer complete')
  
  
    t = input("Enter the time in seconds: ")
  
    countdown(int(t))
      


