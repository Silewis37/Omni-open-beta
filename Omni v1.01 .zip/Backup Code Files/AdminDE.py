import time
print("#Please if you use this And you are not a Dev, Pls ur Admin Username: guest. the User name u are to enter is: guest.")
time.sleep(2)
AdminDE=input(">>Admin Username: ")
if "guest" in AdminDE:
  greeting1=input("hello")
  if "hi" in greeting1:
    name=input('Hey and what is your name, ?\n')
    Day1=input('And how has your day been %s?' % name)
    if "good" in Day1:
      print("Well my day has been amazing, and I bet yours was too!")
    if "bad" in Day1:
      Affect1=input('Well is there any way I can make you happy %s?' % name)
      if "yes" in Affect1:
        Affect2=input("Would you like a hug?")
        if "yes" in Affect2:
          print("Sending Virtual Hug...")
          time.sleep(3)
          print("Please Wait a Moment This takes a little while")
          time.sleep(2)
          print("Virtual Hug Sent!")
          Ans=input('Feel any better %s?' % name)
          if "yes" in Ans:
            Exiter=input('Is that all %s?' % name)
            if "yes" in Exiter:
              print("Have a good rest of your day!")
              time.sleep(2)
              print("Good Bye!")
              exit()
            if "no" in Exiter:
              print("I am sorry but that is all I can Do At the moment, Sorry")
              time.sleep(2)
              print("Good Bye!")
              time.sleep(2)
              exit()
        if "no" in Affect2:
          Quest=input("Do you want any emotional support?")
          if "yes" in Quest:
            print("Then you should probably see a therapist.")
          if "no" in Quest:
            print("Oh ok")
      if "no" in Affect1:
        print("Please call a therapist cause this is all i can do.")
        if "no" in Ans:
              Ans2=input("Do you require me for anything else?")
              if "yes" in Ans2:
                print("Please contact the Devs for any other help.")
                print("Thank you!")
                time.sleep(2)
                print("Good Bye!")
                time.sleep(2)
                exit()    
if "checking up" in AdminDE:
  print("Ok well, I am Doing Great Master!")
  print("Thank you for asking! :D")
if "adding an update" in AdminDE:
  print("Yay! I'm happy that you guys are going to update me! Thank You!!!")
  exit()
if "Sam L" in AdminDE:
  pass1=input("Password: ")
  if "031907" in pass1:
    name1=input('And who is speaking with me?\n')
    if "Sammy" in name1:
      print("Welcome Back Mister Lewis.")
    else:
      print("Sorry, Access Denined")
      time.sleep(1)
      print("Good Bye!")
      time.sleep(2)
      exit()
  else:
    print("Sorry, Access Denied")
    time.sleep(1)
    print("Good Bye!")
    time.sleep(2)
    exit()
if "Sam P" in AdminDE:
  pass2=input("Password: ")
  if "20070411" in pass2:
    name2=input('And who is speaking with me?\n')
    if "Sam P" in name2:
      print("Welcome Back Mister Poyner.")
    else:
      print("Sorry, Access Denined!")
      time.sleep(1)
      print("Good Bye!")
      time.sleep(2)
      exit()
  else:
    print("Sorry, Access Denined!")
    time.sleep(1)
    print("Good Bye!")
    time.sleep(2)
    exit()
time.sleep(2)
exit()